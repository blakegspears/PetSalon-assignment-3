
console.log("Register");

let petSalon ={
    name: "The Wet Pet Salon",
    phone: "555-555-5555",
    address:{
        street: "123 Main St",
        city: "New York",
        state: "NY",
        zip: "123456789"

    },
    pet:[

    ]

}


console.log(petSalon);

//constructor
let c=0;
function Pet(name, age, gender, breed, service, ownerName, contactPhone){
    this.name = name;
    this.age = age;
    this.gender = gender;
    this.breed = breed;
    this.service = service;
    this.owner = ownerName;
    this.phone = contactPhone;
    this.id = c++;
}

function displaypetSalon(){



document.getElementById("Info").innerHTML=`
<p>Name: ${petSalon.name}</p>
<p>Phone: ${petSalon.phone}</p>
<p>Street: ${petSalon.address.street}</p>
<p>City: ${petSalon.address.city}</p>
<p>State: ${petSalon.address.state}</p>
<p>Zip: ${petSalon.address.zip}</p>`;

}
let nameInput = document.getElementById("petName");
let ageInput = document.getElementById("petAge");
let genderInput = document.getElementById("petGender");
let breedInput = document.getElementById("petBreed");
let serviceSelect = document.getElementById("petService");
let ownerName = document.getElementById("ownerName");
let contactPhone = document.getElementById("contactPhone");

function isValid(aPet){
    let valid= true;

    if(aPet.name == "" || aPet.service == "" || aPet.phone == ""){
        valid= false;
    }
    
    return valid;
}

function register(){
    console.log(nameInput.value,ageInput.value,genderInput.value,breedInput.value, ownerName.value, contactPhone.value, serviceSelect.value);
    let thePet = new Pet(nameInput.value, ageInput.value, genderInput.value, breedInput.value, serviceSelect.value, ownerName.value, contactPhone.value);
    if(isValid(thePet)){
        petSalon.pet.push(thePet);
        clearInputs();
        displayPetTable();    
    }else{
        alert("Please add the required information.");
    }
}
    

function clearInputs(){
    nameInput.value = "";
    ageInput.value = "";
    genderInput.value = "";
    breedInput.value = "";
    serviceSelect.value = "";
    ownerName.value = "";
    contactPhone.value = "";
}

function deletePet(id){
    let removeIndex;
    //searching the pet id into the array
    for(let i = 0; i < petSalon.pet.length; i++) {//travel array
        let pet = petSalon.pet[i];//get a pet values
        if(pet.id == id) {//compare id with pets id on array
        removeIndex = i;//get location of pet
        petSalon.pet.splice(removeIndex, 1);//removing pet from array
    document.getElementById(id).remove();//removing pet from html
        }
    }
}

function search(){
    let searchPet = document.getElementById("petSearch").value;
    let searchIndex;
    for(let i = 0; i < petSalon.pet.length; i++) {//travel array
        let pet = petSalon.pet[i];//get a pet values
        if(pet.name == searchPet) {//compare id with pets id on array
        searchIndex = i
console.log("GOT EEEM!");
}
}
}
function init(){
    console.log("Registering");
    displaypetSalon();
    let scooby = new Pet("Scooby", 60, "Male", "Great Dane", "Grooming","Shaggy","111-111-1111");
    petSalon.pet.push(scooby);

    displayPetTable();
   
}

window.onload=init;

function displayPetsNames() {
    for(let i=0; i<petSalon.pet; i++) {
        console.log(petSalon.pet.name[i]);
    }
    
    
}
    

// use alert to display the amount of pets (alert(),length)
// travel the pets array
// displayInfo()
    